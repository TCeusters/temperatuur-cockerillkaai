# Temperatuurgrafiek: Netatmo (binnen) vs. buiten Cockerillkaai

Deze map bevat alles om automatisch, dagelijks, een grafiek online te zetten met
twee lijnen: je **Netatmo-binnentemperatuur** en de **buitentemperatuur op de
Cockerillkaai** (Antwerpen). De grafiek staat op een gratis publieke webpagina
(GitHub Pages) en werkt zichzelf elke dag bij in de cloud — je PC hoeft niet aan
te staan.

Wat er in zit:

- `scripts/build.py` — haalt de data op en maakt de grafiek + een CSV.
- `.github/workflows/update.yml` — laat het dagelijks draaien en publiceert de pagina.
- `README.md` — deze handleiding.

> **Voor wie dit opzet:** de stappen zijn te doen zonder programmeerkennis, maar
> als je een IT-partner hebt, is dit een klus van ~15 minuten die je perfect aan
> hen kunt geven. Geef hen dan deze volledige map.

---

## Deel A — Wat je van Netatmo nodig hebt (stappenplan)

Je hebt **drie gegevens** nodig. Die haal je uit de Netatmo *developer*-portal
(niet de gewone app). De gewone iPhone-app volstaat hier niet; de data komt via
de API.

Je hebt straks nodig:

1. **Client ID**
2. **Client Secret**
3. **Refresh token** (met leesrecht op je weerstation)

Stappenplan:

1. Ga naar **https://dev.netatmo.com** en log in met je **gewone Netatmo-account**
   (hetzelfde als in de app).
2. Klik rechtsboven op je e-mailadres/naam → **Create an app** (of: *My apps* →
   *Create*).
3. Vul de verplichte velden in:
   - **App name**: bv. `Temperatuur Cockerillkaai`
   - **Description**: bv. `Grafiek binnen vs buiten`
   - Als er een **redirect URI** gevraagd wordt: vul `https://localhost` in.
   - Aanvaard de voorwaarden en bewaar.
4. Op de app-pagina zie je nu de **Client ID** en **Client secret**. Noteer beide.
5. Scroll op diezelfde pagina naar **Token generator**:
   - Zet bij *scopes* een vinkje bij **`read_station`** (leesrecht weerstation).
   - Klik **Generate Token** en bevestig de toegang.
   - Je krijgt een **Access token** en een **Refresh token**. Je hebt hier het
     **Refresh token** nodig (het access token vervalt na 3 uur; het script
     maakt zelf steeds een nieuw access token aan met het refresh token).

> ⚠️ **Behandel deze drie gegevens als een wachtwoord.** Deel ze niet publiek en
> mail ze niet rond. Je zet ze straks als versleutelde *secrets* in GitHub
> (Deel C). Ze staan **niet** in de publieke grafiekpagina.
>
> ⚠️ **Mogelijk verouderd:** Netatmo heeft zijn login-procedure de voorbije jaren
> meermaals aangepast. Als de schermen afwijken van hierboven, zoek dan naar
> "Token generator" of "Create an app" op dev.netatmo.com. Kom je er niet uit,
> laat het weten met een screenshot.

---

## Deel B — De GitHub-repo aanmaken

1. Maak (gratis) een account op **https://github.com** als je er nog geen hebt.
2. Klik op **+** rechtsboven → **New repository**.
   - **Repository name**: bv. `temperatuur-cockerillkaai`
   - Zet op **Public** (nodig voor gratis GitHub Pages).
   - Klik **Create repository**.
3. Upload de bestanden uit deze map naar de repo, met **dezelfde mappenstructuur**:
   - `scripts/build.py`
   - `.github/workflows/update.yml`
   - `README.md`

   Makkelijkste manier via de website: klik **Add file → Upload files** en sleep
   de bestanden erin. Belangrijk: het pad `.github/workflows/update.yml` moet
   behouden blijven. Tip: typ bij het uploaden in het bestandsnaamveld
   `.github/workflows/update.yml` — GitHub maakt dan zelf de mappen aan.
   (De bijgeleverde ZIP behoudt de structuur al; die kun je ook gewoon uitpakken
   en de inhoud uploaden.)

---

## Deel C — Secrets instellen (de gevoelige gegevens)

In je repo: **Settings → Secrets and variables → Actions → New repository secret**.
Maak deze vier secrets aan:

| Naam van de secret       | Waarde                                             |
|--------------------------|----------------------------------------------------|
| `NETATMO_CLIENT_ID`      | de Client ID uit Deel A                            |
| `NETATMO_CLIENT_SECRET`  | de Client Secret uit Deel A                        |
| `NETATMO_REFRESH_TOKEN`  | het Refresh token uit Deel A                       |
| `GH_PAT`                 | een GitHub-token (zie hieronder) om het refresh-token te kunnen verversen |

**Waarom `GH_PAT`?** Netatmo geeft bij elke vernieuwing soms een *nieuw*
refresh-token terug en maakt het oude ongeldig. De taak moet dat nieuwe token dan
kunnen wegschrijven, anders stopt het na een dag met werken. Daarvoor is een
token met schrijfrecht op de secrets nodig.

`GH_PAT` aanmaken:

1. Ga naar **https://github.com/settings/tokens** → **Fine-grained tokens** →
   **Generate new token**.
2. **Repository access**: *Only select repositories* → kies deze ene repo.
3. **Permissions → Repository permissions → Secrets**: zet op **Read and write**.
4. Genereer het token, kopieer het, en plak het als secret `GH_PAT` (stap
   hierboven).

---

## Deel D — GitHub Pages aanzetten

In je repo: **Settings → Pages**.

- Bij **Build and deployment → Source**: kies **GitHub Actions**.

Meer hoef je hier niet in te stellen; de workflow publiceert automatisch.

---

## Deel E — Eerste keer draaien en testen

1. Ga in je repo naar het tabblad **Actions**.
2. Kies links **Temperatuurgrafiek bijwerken** → klik rechts **Run workflow** →
   **Run workflow** (dit is de handmatige start; daarna draait het elke dag vanzelf).
3. Wacht ~1 minuut tot het groene vinkje verschijnt.
   - **Gelukt?** Je publieke link staat onder **Settings → Pages** (iets als
     `https://<jouw-gebruikersnaam>.github.io/temperatuur-cockerillkaai/`).
     Die link stuur je door naar externen.
   - **Fout (rood kruisje)?** Klik op de mislukte run → open de stap
     *Grafiek + CSV genereren*. Het script geeft een duidelijke `FOUT:`-regel.
     Meestal is dat een verkeerd overgetypt token. Stuur me die regel dan door.

**Verificatie van de cijfers:** leg bij de eerste geslaagde run de grafiek naast
je Netatmo-app. De binnentemperatuur-lijn moet overeenkomen met wat de app toont.
De buitenlijn is een weermodelwaarde voor de coördinaten, dus die mag licht
afwijken van een thermometer buiten (dat is normaal).

---

## Deel F — Aanpassen (optioneel)

In `.github/workflows/update.yml`, onder de stap *Grafiek + CSV genereren*:

- `DAYS`: aantal dagen historiek in de grafiek (standaard `30`, max `92`).
- `LAT` / `LON`: coördinaten van de buitenmeting. Standaard staan die op de
  Cockerillkaai (`51.212`, `4.399`). Wil je een exactere plek, pas ze aan.
- Tijdstip van de dagelijkse run: de regel `cron: "30 4 * * *"` (in UTC).
  `30 4` = 04:30 UTC ≈ 06:30 Belgische zomertijd.

Na een aanpassing: sla op; de volgende run gebruikt de nieuwe instelling.

---

## Belangrijk om te weten

- De pagina is **publiek**: iedereen met de link ziet de grafiek. Voor
  temperatuurdata is dat weinig gevoelig, maar deel de link bewust.
- De grafiek werkt **één keer per dag** bij. Omdat zowel Netatmo als het
  weermodel historiek teruggeven, wordt een eventueel gemiste dag automatisch
  ingehaald bij de volgende run.
- Dit script gebruikt de **hoofd-binnenmodule** van je station. Heb je extra
  binnensensoren (aparte kamers) en wil je een specifieke, dan pas ik het script
  aan.
- **Netatmo-API kan wijzigen.** Als de dagelijkse taak ooit begint te falen op de
  Netatmo-stap, is het refresh-token meestal verlopen: genereer een nieuw token
  (Deel A, stap 5) en werk de secret `NETATMO_REFRESH_TOKEN` bij.
